create
    definer = root@localhost procedure procedure_update_table(IN table_name varchar(50))
BEGIN
DECLARE i INT;
DECLARE sq VARCHAR(8000);
SET  i = 1 ;
WHILE i < 4 DO
--  拼接字段名
SET @pp = CONCAT('strr',i);
-- 前三个字符类型
IF i < 4 THEN
SET  sq = CONCAT('ALTER table ',table_name,' add column ',@pp, ' VARCHAR(255) ');
END IF;
SET i = i + 1 ;
SET @_SQL = sq ;
-- 预定义sql
PREPARE stmt FROM @_SQL ;
-- 执行sql
EXECUTE stmt ;
-- 释放连接
DEALLOCATE PREPARE stmt;
-- 结束While 循环
END WHILE;
END;

