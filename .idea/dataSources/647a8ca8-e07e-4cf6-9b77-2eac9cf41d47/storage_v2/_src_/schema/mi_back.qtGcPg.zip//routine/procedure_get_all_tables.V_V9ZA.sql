create
    definer = root@localhost procedure procedure_get_all_tables()
BEGIN
-- 用于判断是否结束循环
DECLARE done INT DEFAULT 0;
-- 存储表名称的变量
DECLARE cur VARCHAR(200);
-- 结尾的引号中指定相应数据库
DECLARE tbs_list CURSOR FOR SELECT TABLE_NAME FROM information_schema.`TABLES` WHERE TABLE_Schema = 'mi';
-- 定义 设置循环结束标识done值怎么改变 的逻辑
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1; 
OPEN tbs_list;
-- 循环开始 
REPEAT
FETCH tbs_list INTO cur;
IF NOT done THEN
   CALL procedure_update_table(cur);
END IF;
UNTIL done END REPEAT;
CLOSE tbs_list;
END;

